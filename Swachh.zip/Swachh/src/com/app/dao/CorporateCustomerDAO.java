package com.app.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Corporatecustomer;
import com.app.pojos.CorporatecustomerFeedback;
import com.app.pojos.Customer;

@Repository
public class CorporateCustomerDAO implements CorporateCustomerDAOInterface {

	
	@Autowired
	private SessionFactory session;

	
	public CorporateCustomerDAO() {
		System.out.println("In DAO constructor");
	}
	
	
	
	@Override
	public int registerCorporateCustomer(Corporatecustomer corporatecustomer) {
		int id = (int) session.getCurrentSession().save(corporatecustomer);
		return id;
	}

	@Override
	public Corporatecustomer validateCorporateCustomer(String email, String password) throws SQLException {
		String jpql = "select c from Corporatecustomer c where c.email=:email and c.password=:password";
		Corporatecustomer info = session.getCurrentSession().createQuery(jpql, Corporatecustomer.class).setParameter("email", email)
				.setParameter("password", password).getSingleResult();
		System.out.println("in validation CorporateCustomer");
		return info;	}
	@Override
	public int feedbackCorporateCustomer(CorporatecustomerFeedback corporatecustomer)
	{
		
		int id = (int) session.getCurrentSession().save(corporatecustomer);
		return id;
	}
}
