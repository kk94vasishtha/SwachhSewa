package com.app.dao;


import java.sql.SQLException;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Corporatecustomer;
import com.app.pojos.CorporatecustomerFeedback;
import com.app.pojos.Customer;

import java.util.List;

public interface CorporateCustomerDAOInterface {
	
	
	public int registerCorporateCustomer(Corporatecustomer corporatecustomer);
	public Corporatecustomer validateCorporateCustomer(String email,String password)throws SQLException;
	public int feedbackCorporateCustomer(CorporatecustomerFeedback corporatecustomer);
}
