package com.app.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Request;

public interface CleanerDAOInterface {
	public int registerCleaner(CleanerInfo cleanerInfo);
	public CleanerInfo validateCleaner(String mobile,String password)throws Exception;
	public Customer checkRequestMethod(Integer customerId) throws Exception;
	
	public String updateStatus(Integer cleanerid);
	public CleanerInfo getCleaner(Integer cleanerid);
	Request getRequest(Integer cleanerid);
	
	public String saveOrUpdate(CleanerInfo cleanerInfo); //for edit details page to update the cleaner Info 
	String addMoneyToCleaner(Double updatedBalance,Integer cleanerId); // to update the balance or add money for addmoney page
}
