package com.app.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.SQLQuery;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Request;

@Repository
public class CleanerDAO implements CleanerDAOInterface {

	@Autowired
	private SessionFactory session;
	
	public CleanerDAO() {
		System.out.println("In DAO constructor");
	}

	@Override
	public int registerCleaner(CleanerInfo cleanerInfo) {
		int id = (int) session.getCurrentSession().save(cleanerInfo);
		return id;
	}

	@Override
	public CleanerInfo validateCleaner(String mob, String pass) throws SQLException {
		String jpql = "select c from CleanerInfo c where c.mobile=:mobile and c.password=:password";
		CleanerInfo info = session.getCurrentSession().createQuery(jpql, CleanerInfo.class).setParameter("mobile", mob)
				.setParameter("password", pass).getSingleResult();
		System.out.println("in validation cleaner");
		return info;

	}

	@Override
	public Customer checkRequestMethod(Integer customerid) throws SQLException {
		String jpql = "select cust from Customer cust where cust.customerId=:id";
		Customer customers = session.getCurrentSession().get(Customer.class,customerid);
		System.out.println(customers);
		return customers;
	}

	@Override
	public String updateStatus(Integer cleanerid) {
		CleanerInfo cleanerInfo = session.getCurrentSession().get(CleanerInfo.class,cleanerid);
		String status = cleanerInfo.getAvailable();
		System.out.println("Your Status " + status);
		if(status.equals("true"))
			cleanerInfo.setAvailable("false");
		if(status.equals("false") || status.equals(null))
			cleanerInfo.setAvailable("true");
		session.getCurrentSession().saveOrUpdate(cleanerInfo);
		System.out.println("Your current Status " + cleanerInfo.getAvailable());
		 return "Available status update successfully";
	}
	
	@Override
	public CleanerInfo getCleaner(Integer cleanerid) {
		return session.getCurrentSession().get(CleanerInfo.class, cleanerid);
	}

	@Override
	public String saveOrUpdate(CleanerInfo cleanerInfo) {
		session.getCurrentSession().saveOrUpdate(cleanerInfo);
		return "Updated Successfully";
	}

	@Override
	public String addMoneyToCleaner(Double updatedBalance,Integer cleanerId) {
		System.out.println("Cleaner ID in DAO class" + cleanerId);
		String jpql = "Update CleanerInfo cleaner set cleaner.balance=:updateBalance where cleaner.cleanerId=:id";
		session.getCurrentSession().createQuery(jpql).setParameter("updateBalance", updatedBalance).setParameter("id", cleanerId).executeUpdate();
		
		return "balance Update Successfully";
	}

	@Override
	public Request getRequest(Integer cleanerid) {
		System.out.println("In DAO Class Request");
		String jpql = "select req from Request req where req.cleanerInfo.cleanerId=:id";
		Request request = session.getCurrentSession().createQuery(jpql, Request.class).setParameter("id", cleanerid).getSingleResult();
		return request;
	}
	

}
