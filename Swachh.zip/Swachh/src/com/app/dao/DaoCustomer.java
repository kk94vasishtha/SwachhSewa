package com.app.dao;

import java.sql.SQLException;
import java.util.List;

import com.app.pojos.*;

public interface DaoCustomer {

	public int savedetails(Customer c) throws SQLException;
	public Customer validate(String email,String password) throws Exception;
	public List<CleanerInfo> getdetailsCleaner() throws Exception;
	public CleanerInfo getCleanerDetails(int id) throws NullPointerException;
	public Customer getCustomerid(String email,String password) throws Exception;
	public int request(Request r) throws NullPointerException;
	public List<Product> getProductdetails() throws Exception;
	public Product getProductDetails(int id) throws Exception;
	public int addcustomercart(Customercart c) throws Exception;
	public List<Customercart> getcartdetails(Customer c) throws Exception;
	
	Request getRequest(Integer customerId) throws Exception;

	public Customer getCustomer(Integer customerId) throws Exception;
	public String saveOrUpdate(Customer customer) throws Exception; //for edit details page to update the cleaner Info 
	String addMoneyToCustomer(Double updatedBalance,Integer customerId) throws Exception; // to update the balance or add money for addmoney page
    public String deletecart(Customercart ct);
	public Customercart getcartdetails(int id);
	
	public long genratebill(Customer c);
	
	public Request getOTP(String OTP);
}
