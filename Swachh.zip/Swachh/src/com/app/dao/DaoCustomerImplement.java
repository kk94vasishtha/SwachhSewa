package com.app.dao;

import java.sql.SQLException;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Customercart;
import com.app.pojos.Product;
import com.app.pojos.Request;

@Repository
public class DaoCustomerImplement implements DaoCustomer {

	@Autowired
	private SessionFactory sf;
	
	
	@Override
	public int savedetails(Customer c) throws SQLException {
		
	  int id =(int)sf.openSession().save(c);
	  return id ;
	        
	}


	@Override
	public Customer validate(String email, String password)throws Exception {
		
		return sf.getCurrentSession().createQuery
				 ("select c from Customer c where c.email=:email and c.password=:password",Customer.class).
				 setParameter("email", email).setParameter("password",password).
				 getSingleResult();
		
	}


	@Override
	public List<CleanerInfo> getdetailsCleaner()throws Exception {
		return sf.getCurrentSession().createQuery("select c from CleanerInfo c",CleanerInfo.class).getResultList();
	}


	@Override
	public CleanerInfo getCleanerDetails(int id) throws NullPointerException{
		return sf.getCurrentSession().get(CleanerInfo.class,id);
	}


	@Override
	public Customer getCustomerid(String email, String password) throws Exception{
		    return sf.getCurrentSession().
	        createQuery("select c.customerId from Customer c where c.email=:email and c.password=:password",Customer.class)
	          .setParameter("email", email).setParameter("password", password).getSingleResult();
	}


	@Override
	public int request(Request r) throws NullPointerException {
		return (int) sf.getCurrentSession().save(r);
	}


	@Override
	public List<Product> getProductdetails() throws Exception {
		
		return sf.getCurrentSession().createQuery("select p from Product p",Product.class).getResultList();
	}


	@Override
	public Product getProductDetails(int id) throws Exception {
		return sf.getCurrentSession().get(Product.class, id);
	}


	@Override
	public int addcustomercart(Customercart c) throws Exception {
		return (int)sf.getCurrentSession().save(c);
	}


	@Override
	public List<Customercart> getcartdetails(Customer c) throws Exception {
		return sf.getCurrentSession().
				createQuery("select c from Customercart c where c.customer=:c",Customercart.class).setParameter("c", c).getResultList();
	}

	@Override
	public Request getRequest(Integer customerId) throws Exception {
		System.out.println("In DAO Class Request");
		String jpql = "select req from Request req where req.customer.customerId=:id";
		Request request = sf.getCurrentSession().createQuery(jpql, Request.class).setParameter("id", customerId).getSingleResult();
		return request;
	}


	@Override
	public String saveOrUpdate(Customer customer) throws Exception {
		sf.getCurrentSession().saveOrUpdate(customer);
		return "Updated Successfully";
	}


	@Override
	public String addMoneyToCustomer(Double updatedBalance, Integer customerId) throws Exception {
		System.out.println("Cleaner ID in DAO class" + customerId);
		String jpql = "Update Customer customer set customer.balance=:updateBalance where customer.customerId=:id";
		sf.getCurrentSession().createQuery(jpql).setParameter("updateBalance", updatedBalance).setParameter("id", customerId).executeUpdate();	
		return "balance Update Successfully";
	}


	@Override
	public Customer getCustomer(Integer customerId) throws Exception {
		return sf.getCurrentSession().get(Customer.class, customerId);
	}


	@Override
	public String deletecart(Customercart ct) {
	  sf.getCurrentSession().delete(ct);
	  return "Delete cart Successfully";
	}


	@Override
	public Customercart getcartdetails(int id) {
		return sf.getCurrentSession().get(Customercart.class,id);
	}


	@Override
	public long genratebill(Customer c) {
		return sf.getCurrentSession().createQuery("select Sum(c.productPrice) from Customercart c where c.customer=:c",Customercart.class)
				.setParameter("c",c).getFirstResult();
	}


	@Override
	public Request getOTP(String OTP) {
		return sf.getCurrentSession().createQuery("Select r from Request r where r.OTP=:OTP",Request.class).
				setParameter("OTP",OTP).getSingleResult();
	}

}
