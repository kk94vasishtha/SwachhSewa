package com.app.pojos;
// Generated Jan 23, 2018 7:00:02 PM by Hibernate Tools 5.2.3.Final

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import static javax.persistence.GenerationType.IDENTITY;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "corporatecustomer", catalog = "swachhsewa", uniqueConstraints = {
		@UniqueConstraint(columnNames = "Contact"), @UniqueConstraint(columnNames = "CorporateCustomer_AC_ID"),
		@UniqueConstraint(columnNames = "Email"), @UniqueConstraint(columnNames = "Username") })
public class Corporatecustomer implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Integer corporateCustomerId;
	private String companyName;
	private String contact;
	private String username;
	private String email;
	private String password;
	private String colony;
	private String city;
	private String state;
	private String zipcode;
	private Integer corporateCustomerAcId;
	private Double balance;
	private Set<CorporatecustomerFeedback> corporatecustomerFeedbacks = new HashSet<CorporatecustomerFeedback>(0);

	public Corporatecustomer() {
	}

	public Corporatecustomer(String companyName, String email, String password, String colony, String city,
			String state, String zipcode) {
		this.companyName = companyName;
		this.email = email;
		this.password = password;
		this.colony = colony;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
	}

	public Corporatecustomer(String companyName, String contact, String username, String email, String password,
			String colony, String city, String state, String zipcode, Integer corporateCustomerAcId, Double balance,
			Set<CorporatecustomerFeedback> corporatecustomerFeedbacks) {
		this.companyName = companyName;
		this.contact = contact;
		this.username = username;
		this.email = email;
		this.password = password;
		this.colony = colony;
		this.city = city;
		this.state = state;
		this.zipcode = zipcode;
		this.corporateCustomerAcId = corporateCustomerAcId;
		this.balance = balance;
		this.corporatecustomerFeedbacks = corporatecustomerFeedbacks;
	}

	@Id
	@GeneratedValue(strategy = IDENTITY)

	@Column(name = "CorporateCustomer_ID", unique = true, nullable = false)
	public Integer getCorporateCustomerId() {
		return this.corporateCustomerId;
	}

	public void setCorporateCustomerId(Integer corporateCustomerId) {
		this.corporateCustomerId = corporateCustomerId;
	}

	@Column(name = "Company_Name", nullable = false, length = 30)
	public String getCompanyName() {
		return this.companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	@Column(name = "Contact", unique = true)
	public String getContact() {
		return this.contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	@Column(name = "Username", unique = true, length = 30)
	public String getUsername() {
		return this.username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name = "Email", unique = true, nullable = false, length = 30)
	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Column(name = "Password", nullable = false, length = 15)
	public String getPassword() {
		return this.password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Column(name = "COLONY", nullable = false, length = 30)
	public String getColony() {
		return this.colony;
	}

	public void setColony(String colony) {
		this.colony = colony;
	}

	@Column(name = "CITY", nullable = false, length = 20)
	public String getCity() {
		return this.city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "STATE", nullable = false, length = 20)
	public String getState() {
		return this.state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Column(name = "ZIPCODE", nullable = false)
	public String getZipcode() {
		return this.zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	@Column(name = "CorporateCustomer_AC_ID", unique = true)
	public Integer getCorporateCustomerAcId() {
		return this.corporateCustomerAcId;
	}

	public void setCorporateCustomerAcId(Integer corporateCustomerAcId) {
		this.corporateCustomerAcId = corporateCustomerAcId;
	}

	@Column(name = "BALANCE", precision = 22, scale = 0)
	public Double getBalance() {
		return this.balance;
	}

	public void setBalance(Double balance) {
		this.balance = balance;
	}

	@OneToMany(fetch = FetchType.LAZY, mappedBy = "corporatecustomer")
	public Set<CorporatecustomerFeedback> getCorporatecustomerFeedbacks() {
		return this.corporatecustomerFeedbacks;
	}

	public void setCorporatecustomerFeedbacks(Set<CorporatecustomerFeedback> corporatecustomerFeedbacks) {
		this.corporatecustomerFeedbacks = corporatecustomerFeedbacks;
	}

}
