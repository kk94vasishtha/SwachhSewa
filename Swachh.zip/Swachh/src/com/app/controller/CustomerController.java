package com.app.controller;

import java.sql.SQLException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Request;
import com.app.service.CleanerService;
import com.app.service.CustomerService;

@Controller
@RequestMapping("/customer")
public class CustomerController {

	@Autowired
	private CustomerService service;

	public static Integer customerId;
	public Double updatedBalance, balance;

	public CustomerController() {
		System.out.println("In customer controller");
	}

	@GetMapping("/customerregister")
	public String savedetails(Customer c) {
		System.out.println("In register form of customer" + c);
		return "customer/customerregister";
	}

	@PostMapping("/customerregister")
	public String processRegistrationForm(Customer c, RedirectAttributes attributes, HttpServletRequest req,
			Model map) {
		System.out.println("In processRegistration Form" + map);
		int id;
		try {
			id = (int) service.savedetails(c);
			System.out.println("Customer" + c);
			attributes.addFlashAttribute("Your Id" + id);
			return "redirect:customer/loginCustomer";
		} catch (Exception e) {
			attributes.addFlashAttribute("message", "Your entered details exists already. Please enter valid details");
			return "redirect:/customer/customerregister";
		}
	}

	@GetMapping("/loginCustomer")
	public String validate(Customer c) {
		System.out.println("In login form show" + c);
		return "customer/loginCustomer";

	}

	@PostMapping("/loginCustomer")
	public String processingLoginForm(Customer c, RedirectAttributes atr, HttpServletRequest req, Model map) {
		System.out.println("I am in processing Log in for customer" + c);
		try {
			Customer validate = service.validate(c.getEmail(), c.getPassword());
			if (validate != null)
				System.out.println(validate.getCustomerId());
			customerId = validate.getCustomerId();
			HttpSession hs = req.getSession();
			hs.setAttribute("User", validate);
			atr.addFlashAttribute("message", "Log in successfully");
			System.out.println("in try block");
			return "customer/customerhome";

		} catch (Exception e) {
			System.out.println("In catch block of processing logn form");
			e.printStackTrace();
			map.addAttribute("message", "Invalid Log in plz retry");
			return "customer/loginCustomer";

		}

	}

	@RequestMapping("/searchCleaner")
	public ModelAndView listCleaner(Model map, RedirectAttributes flashMap) {
		System.out.println("in list cleaners");
		try {
			map.addAttribute("Cleaner_list", service.getdetailsCleaner());
			return new ModelAndView("customer/searchCleaner");
		} catch (Exception e) {
			flashMap.addFlashAttribute("message", "No Cleaner List Available");
			return new ModelAndView("customer/searchCleaner");
		}
	}

	@GetMapping("/select/{id}")
	public String getCleanerId(@PathVariable int id, HttpServletRequest req, Model map) {
		System.out.println("in selectd Cleaner_id " + id);
		CleanerInfo clean = service.getCleanerdetails(id);
		System.out.println(clean);
		map.addAttribute("cleanerdetail", clean);
		// --Generate OTP
		int randomepin = (int) (Math.random() * 90000) + 100;
		String OTP = String.valueOf(randomepin);
		HttpSession hs = req.getSession();
		Customer c = (Customer) hs.getAttribute("User");
		Request re = new Request(clean, c, OTP);
		hs.setAttribute("Requset", re);
		int id1 = (int) service.request(re);
		System.out.println(id1);
		return "customer/selectnew";
	}

	@GetMapping("/confirm")
	public String request(HttpServletRequest req, Model map) {
		System.out.println("I am in confirm");
		String OTP = req.getParameter("OTP");
		System.out.println("value of  otp " + OTP);
		
		try {
			Request re = service.getOTP(OTP);
			if (re!=null) {
				
				System.out.println("In if block ");
				return "redirect:/customer/billgenerate";
			} 
			else 
			{
				System.out.println("in else block");
				return "customer/loginCustomer";
			}
		 } 
		 catch (Exception e) {
			return "customer/loginCustomer";
		}

	}

	@GetMapping("/viewdetails")
	public String viewDetails(HttpServletRequest request, RedirectAttributes flashMap, Model map) {
		System.out.println("in the get mapping of view details");
		HttpSession session = request.getSession();
		Customer customer = (Customer) session.getAttribute("User");
		Customer cust;
		try {
			cust = service.getCustomer(customer.getCustomerId());
			System.out.println(cust);
			map.addAttribute("customer", cust);
			return "customer/viewdetails";
		} catch (Exception e) {
			flashMap.addFlashAttribute("message", "No data to display");
			return "redirect:/customer/customerhome";
		}

	}

	@GetMapping("/editdetails/{id}")
	public String editCleanerInfo(@PathVariable int id, RedirectAttributes flashMap, Customer customer, Model map) {
		System.out.println("In edit cleaner info post mapping" + id);
		try {
			customer = service.getCustomer(id);
			System.out.println(customer);
			map.addAttribute("customer", customer);
			return "/customer/editdetails";
		} catch (Exception e) {
			flashMap.addFlashAttribute("message", "Sorry Your record is not available");
			return "redirect:/customer/viewdetails";
		}
	}

	@PostMapping("/process_update")
	public String processUpdateForm(Customer customer, RedirectAttributes flashMap) {
		System.out.println("in process update form" + customer);
		try {
			flashMap.addFlashAttribute("message", service.saveOrUpdate(customer));
			return "redirect:/customer/viewdetails";
		} catch (Exception e) {
			flashMap.addFlashAttribute("message", "Your information can not be updated");
			return "redirect:/customer/viewdetails";
		}

	}

	@GetMapping("/addmoney/{id}")
	public String showAddMoneyPage(@PathVariable int id, Customer customer, RedirectAttributes flash, Model map) {
		System.out.println("In show add money page " + id);
		try {
			customer = service.getCustomer(id);
			customerId = customer.getCustomerId();
			balance = customer.getBalance();
			if (balance == null)
				balance = 0.0;
			System.out.println("Current Balance is :" + balance);
			System.out.println(customer);
			map.addAttribute("customer", customer);
			return "/customer/addmoney";
		} catch (Exception e) {
			flash.addFlashAttribute("add", "Currently, we donot have your account details");
			return "redirect:/customer/viewdetails";
		}
	}

	@PostMapping("/process_add_money")
	public String processAddMoney(HttpServletRequest request, Customer customer, RedirectAttributes flashMap) {
		updatedBalance = Double.parseDouble(request.getParameter("addMoney"));
		System.out.println("Updated Balance" + updatedBalance);
		updatedBalance += balance;
		System.out.println("Updated Balance" + updatedBalance);
		System.out.println("Customer Id : " + customerId);
		try {
			service.addMoneyToCustomer(updatedBalance, customerId);
			System.out.println("in process update form" + customer);
			return "redirect:/customer/viewdetails";
		} catch (Exception e) {
			flashMap.addFlashAttribute("add", "Your balance can not be updated");
			return "redirect:/customer/viewdetails";
		}
	}

	@GetMapping("/billgenerate")
	public String BillGenerate(Model map) {
		System.out.println("I am in bill generate ");
		return "/customer/billgenerate";

	}
	
	@GetMapping("/customerhome")
     public String CustomerHome(Model map)
     {
		System.out.println("I am in Customerhome");
		return "/customer/customerhome";
		
     }
	@GetMapping("/logout")
	public String logout(HttpServletRequest req)
	{
		System.out.println("I am in logout");
		HttpSession hs = req.getSession();
		hs.invalidate();
		return "redirect:/customer/loginCustomer";
	}

}
