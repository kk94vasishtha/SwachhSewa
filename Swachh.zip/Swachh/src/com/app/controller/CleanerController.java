package com.app.controller;

import java.text.ParseException;
import java.util.List;

import javax.persistence.NoResultException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.jasper.JasperException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Request;
import com.app.service.CleanerServiceInterface;

@Controller
@RequestMapping("/cleaner")
public class CleanerController {
	@Autowired
	private CleanerServiceInterface service;

	public static Integer cleanerId;
	public Double updatedBalance, balance;

	public CleanerController() {
		System.out.println("In cleaner controller");
	}

	@GetMapping("/viewdetails")
	public String viewDetails(HttpServletRequest request, Model map) {
		System.out.println("in the get mapping of view details");
		HttpSession session = request.getSession();
		CleanerInfo cleanerInfo = (CleanerInfo) session.getAttribute("cleaner");
		CleanerInfo cleaner = service.getCleaner(cleanerInfo.getCleanerId());
		System.out.println(cleaner);
		map.addAttribute("cleaner", cleaner);
		return "/cleaner/viewdetails";
	}

	@GetMapping("/listdetails/{id}")
	public String listCustomers(@PathVariable int id, CleanerInfo cleanerInfo, RedirectAttributes flashMap,
			Model model) {
		System.out.println("in list details page");
		try {
			Request request = service.getRequest(id);
			String str = request.getOTP();
			System.out.println("Value of request OTP " + str);
			int customerid = request.getCustomer().getCustomerId();
			System.out.println("Customer ID is " + customerid);
			Customer customer;
			try {
				customer = service.checkRequest(customerid);
				System.out.println("after method " + customer.getFirstName());
				model.addAttribute("list", customer);
				model.addAttribute("request", request);
				System.out.println("task performed");
				return "/cleaner/listdetails";
			} catch (Exception e) {
				flashMap.addAttribute("listmessage", "Sorry, No Request for you....");
				return "redirect:/cleaner/cleanerhome";
			}
		} catch (Exception e) {
			flashMap.addFlashAttribute("listmessage", "Sorry, No Request for you....");
			return "redirect:/cleaner/cleanerhome";
		}
	}

	@GetMapping("/editdetails/{id}")
	public String editCleanerInfo(@PathVariable int id, CleanerInfo cleanerInfo, Model map) {
		System.out.println("In edit cleaner info post mapping" + id);
		cleanerInfo = service.getCleaner(id);
		System.out.println(cleanerInfo);
		map.addAttribute("cleanerInfo", cleanerInfo);
		return "/cleaner/editdetails";
	}

	@PostMapping("/process_update")
	public String processUpdateForm(CleanerInfo cleanerInfo, RedirectAttributes flashMap) {
		System.out.println("in process update form" + cleanerInfo);
		flashMap.addFlashAttribute("message", service.saveOrUpdate(cleanerInfo));
		return "redirect:/cleaner/viewdetails";
	}

	@GetMapping("/addmoney/{id}")
	public String showAddMoneyPage(@PathVariable int id, CleanerInfo cleanerInfo, Model map) {
		System.out.println("In show add money page " + id);
		cleanerInfo = service.getCleaner(id);
		cleanerId = cleanerInfo.getCleanerId();
		balance = cleanerInfo.getBalance();
		if (balance == null)
			balance = 0.0;
		System.out.println("Current Balance is :" + balance);
		System.out.println(cleanerInfo);
		map.addAttribute("cleanerInfo", cleanerInfo);
		return "/cleaner/addmoney";
	}

	@PostMapping("/process_add_money")
	public String processAddMoney(HttpServletRequest request, CleanerInfo cleanerInfo, RedirectAttributes flashMap) {
		updatedBalance = Double.parseDouble(request.getParameter("addMoney"));
		System.out.println("Updated Balance" + updatedBalance);
		updatedBalance += balance;
		System.out.println("Updated Balance" + updatedBalance);
		System.out.println("Cleaner Id : " + cleanerId);
		service.addMoneyToCleaner(updatedBalance, cleanerId);
		System.out.println("in process update form" + cleanerInfo);
		return "redirect:/cleaner/viewdetails";
	}

	/*
	 * @GetMapping("/duty") public String changeStatus(CleanerInfo cleanerInfo)
	 * { System.out.println("in the get mapping of duty" + cleanerInfo); return
	 * "/cleaner/duty"; }
	 */
	@RequestMapping("/duty/{id}")
	public String processUpdateStatus(@PathVariable int id, CleanerInfo cleanerInfo, RedirectAttributes flashMap,
			Model map) {
		cleanerInfo = service.getCleaner(id);
		cleanerId = cleanerInfo.getCleanerId();
		System.out.println("In process update status" + map);
		flashMap.addAttribute("updateStatus", service.updateStatus(cleanerId));
		System.out.println("before return page of duty");
		return "redirect:/cleaner/cleanerhome";
	}

	@GetMapping("/logout")
	public String logoutCleaner(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		/* return "redirect:/"; */
		return "redirect:/cleaner/loginCleaner";
	}

	@GetMapping("/cleanerregister")
	public String showRegisterForm(CleanerInfo cleanerInfo) {
		System.out.println("In register show form" + cleanerInfo);
		return "/cleaner/cleanerregister";
	}

	@PostMapping("/cleanerregister")
	public String processRegisterForm(CleanerInfo cleanerInfo, RedirectAttributes flashMap, Model map)
			throws ParseException {
		System.out.println("In Process Registeration Form " + map);
		int id = service.saveCleaner(cleanerInfo);
		System.out.println("cleaner " + cleanerInfo);
		flashMap.addFlashAttribute("Your ID : ", id);
		return "redirect:/cleaner/loginCleaner";
	}

	@GetMapping("/loginCleaner")
	public String showLoginForm(CleanerInfo cleanerInfo) {
		System.out.println("In login show form" + cleanerInfo);
		return "/cleaner/loginCleaner";
	}

	@PostMapping("/loginCleaner")
	public String processLoginForm(CleanerInfo cleanerInfo, RedirectAttributes attributes, HttpServletRequest request,
			Model map) {
		System.out.println("In Cleaner Process Login Form" + map);

		try {
			CleanerInfo validCleaner = service.validateCleaner(cleanerInfo.getMobile(), cleanerInfo.getPassword());
			attributes.addFlashAttribute("message", "Logged in successfully");
			HttpSession session = request.getSession();
			session.setAttribute("cleaner", validCleaner);
			cleanerId = validCleaner.getCleanerId();
			System.out.println("Cleaner ID = " + cleanerId);
			System.out.println("in try block");
			return "redirect:/cleaner/cleanerhome";

		} catch (Exception e) {
			System.out.println("in catch block");
			e.printStackTrace();
			map.addAttribute("message", "Invalid Login Please retry ...");
			return "/cleaner/loginCleaner";
		}
	}

	@GetMapping("/cleanerhome")
	public String showCleanerForm(CleanerInfo cleanerInfo) {
		System.out.println("In register show form" + cleanerInfo);
		return "/cleaner/cleanerhome";
	}
	
	
}
