package com.app.controller;

import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.Corporatecustomer;
import com.app.pojos.CorporatecustomerFeedback;
import com.app.service.CorporateCustomerServiceInterface;


@Controller
@RequestMapping("/corporatecustomer")
public class CorporateController {
	
	@Autowired
	private CorporateCustomerServiceInterface service;
	
	
	
public static int CorporateCustomerID;
	
	public CorporateController() {
		System.out.println("In Corporatecustomer controller");
	}
	
	public static Integer corporatecustomerid;
	
	
	@GetMapping("/logout")
	public String logoutCorporateleaner(HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.invalidate();
		/* return "redirect:/"; */
		return "redirect:logincoporatecustomer";
	}

	

	@GetMapping("/checkrequest")
	public String showcheckList(Corporatecustomer corporatecustomer) {
		System.out.println("In register show form" + corporatecustomer);
		return "/corporatecustomer/corporatecustomerregister";
	}

	/*@PostMapping("/checkrequest")
	public String showCheckRequest(Model map) {
		System.out.println("In Check Request processing form" + map);
		try {
			System.out.println("In try block of check request");
			map.addAttribute("cust_list", service.checkRequest(CorporateCustomerID));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:/cleaner/checkrequest";
	}
	*/

	@GetMapping("/corporatecustomerhome")
	public String showCorporateCustomerForm(Corporatecustomer corporatecustomer) {
		System.out.println("In register show form" + corporatecustomer);
		return "/corporatecustomer/corporatecustomerhome";
	}

	
	
	@GetMapping("/corporatecustomerregister")
	public String showCorporateCustomerRegisterForm(Corporatecustomer corporatecustomer) {
		System.out.println("In register show form" + corporatecustomer);
		return "/corporatecustomer/corporatecustomerregister";
	}

	
	@GetMapping("/logincorporatecustomer")
	public String showLoginForm(Corporatecustomer corporatecustomer) {
		System.out.println("In login show form" + corporatecustomer);
		return "/corporatecustomer/logincorporatecustomer";
	}

	@PostMapping("/logincorporatecustomer")
	public String processLoginForm(Corporatecustomer corporatecustomer, RedirectAttributes attributes, HttpServletRequest request,
			Model map) {
		System.out.println("In Corporatecustomer Process Login Form" + map);

		try {
			Corporatecustomer validCorporatecustomer = service.validateCorporatecustomer(corporatecustomer.getEmail(), corporatecustomer.getPassword());
			System.out.println("1");
			attributes.addFlashAttribute("message", "Logged in successfully");
			System.out.println("2");
			HttpSession session = request.getSession();
			System.out.println("3");
			session.setAttribute("Corporatecustomer", corporatecustomer);
			System.out.println("4");
			
			System.out.println("in try block");
			return "redirect:/corporatecustomer/corporatecustomerhome";

		} catch (Exception e) {
			System.out.println("in catch block");
			e.printStackTrace();
			map.addAttribute("message", "Invalid Login Please retry ...");
			return "/corporatecustomer/logincorporatecustomer";
		}
	}

	@PostMapping("/corporatecustomerregister")
	public String processRegisterForm(Corporatecustomer corporatecustomer, RedirectAttributes flashMap, Model map)
			throws ParseException {
		System.out.println("In Process Registeration Form " + map);
		int id = service.saveCorporateCustomer(corporatecustomer);
		System.out.println("Corporatecustomer " + corporatecustomer);
		flashMap.addFlashAttribute("Your ID : ", id);
		return "redirect:/corporatecustomer/logincorporatecustomer";
	}
	
	
	
	
	@GetMapping("/feedback")
	public String feedbackForm(CorporatecustomerFeedback corporatecustomer) {
		System.out.println("In feedback form" + corporatecustomer);
		return "/corporatecustomer/feedback";
	}
	
	@PostMapping("/feedback")
	public String processfeedbackForm(CorporatecustomerFeedback corporatecustomer, RedirectAttributes flashMap, Model map)
			throws ParseException {
		System.out.println("In Feedback Form " + map);
		
		int id = service.saveFeedback(corporatecustomer);
		System.out.println("Corporatecustomer " + corporatecustomer);
		
		flashMap.addFlashAttribute("Your ID : ", id);
		return "redirect:/corporatecustomer/feedback";
	}
	

	
}

	
	
	


