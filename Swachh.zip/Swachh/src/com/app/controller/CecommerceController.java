package com.app.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Customercart;
import com.app.pojos.Product;
import com.app.pojos.Request;
import com.app.service.CustomerService;

@Controller
@RequestMapping("/ecommerce")
public class CecommerceController {
	@Autowired
	private CustomerService service;

	public CecommerceController() {
		System.out.println("I am in E-Commerce Controller");

	}

	@GetMapping("/commerce")
	public String commerce() {
		System.out.println("I am in commerec getmapping");

		return "ecommerce/commerce";

	}

	/*@GetMapping("/usercommerce")
	public String usercommerec(HttpServletRequest req, Model map) {
		HttpSession hs = req.getSession();
		Customer c = (Customer) hs.getAttribute("User");
		System.out.println("I am in user e commerec getmapping");
		map.addAttribute("customer", c);
		return "ecommerce/usercommerce";
	}*/

	@GetMapping("/addtocart")
	public String addtocart(Model map) {
		System.out.println("In List of product");
		try {
			map.addAttribute("product_list", service.getProduct());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "ecommerce/addtocart";
	}

	@GetMapping("/addtocart/{id}")
	public String customercart(@PathVariable int id, HttpServletRequest req,RedirectAttributes flash, Model map) {
		System.out.println("I am in PostMapping in addto cart");
		try {
			map.addAttribute("product_list", service.getProduct());
			HttpSession hs = req.getSession();
			Customer c = (Customer) hs.getAttribute("User");
			Product p = (Product) service.getProductDetails(id);
			Customercart cart = new Customercart(c, p, p.getProductName(), p.getProductPrice());
			int id1=service.addcustomercart(cart);
			System.out.println(id1);
			return "redirect:/ecommerce/addtocart";
		} catch (Exception e) {
			flash.addFlashAttribute("cart", "Page can not be loaded");
			return "redirect:/customer/customerhome";
		}
		

	}
	@GetMapping("/showcart")
	public String showcart(HttpServletRequest req,RedirectAttributes flash,Model map) throws Exception
	{
		map.addAttribute("product_list", service.getProduct());
		System.out.println("I am in show cart");
		HttpSession hs = req.getSession();
		Customer c = (Customer)hs.getAttribute("User");
        try {
			map.addAttribute("customercart",service.getcartdetails(c));
			return "ecommerce/addtocart";
		} catch (Exception e) {
			flash.addFlashAttribute("cart", "Could not fetch your cart details");
			return "redirect:/customer/customerhome";
		}
	}
	
	@GetMapping("/deletecart")
	public String deletetocart(@RequestParam int cartid,RedirectAttributes flashMap)
	{
		System.out.println("In delete cart"+cartid);
		flashMap.addFlashAttribute("message", service.deletecart(cartid));
		return "redirect:/ecommerce/addtocart";
		
	}
	
	@GetMapping("/genratebill")
	public String genratebill(HttpServletRequest req,Model map) throws Exception
	{
		System.out.println("I am in geratebill");
		HttpSession hs = req.getSession();
		Customer c = (Customer)hs.getAttribute("User");
		ArrayList<Customercart> cart = (ArrayList<Customercart>) service.getcartdetails(c);
		long total=0;
		for(Customercart i: cart)
		{
			total +=i.getProductPrice();
			
		}
		
		System.out.println("total"+total);
		map.addAttribute("total", total);
	
			return "ecommerce/genratebill";
	}
	
}
