package com.app.service;


import com.app.pojos.Corporatecustomer;
import com.app.pojos.CorporatecustomerFeedback;

import java.util.List;

public interface CorporateCustomerServiceInterface {
	
	
	public int saveCorporateCustomer(Corporatecustomer corporatecustomer);
	public Corporatecustomer validateCorporatecustomer(String email,String password)throws Exception;
	public int saveFeedback(CorporatecustomerFeedback corporatecustomer);
}
