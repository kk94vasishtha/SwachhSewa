package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.app.dao.CorporateCustomerDAOInterface;
import com.app.pojos.Corporatecustomer;
import com.app.pojos.CorporatecustomerFeedback;




@Service
@Transactional
public class CorporateCustomerService implements CorporateCustomerServiceInterface {

	
	@Autowired
	private CorporateCustomerDAOInterface dao;
	
	public CorporateCustomerService() {
		System.out.println("In CorporateCustomerService constructor");
	}
	
	
	
	@Override
	public int saveCorporateCustomer(Corporatecustomer corporatecustomer) {
		System.out.println("saving the details of CorporateCustomer");
		return dao.registerCorporateCustomer(corporatecustomer);
	}

	
	
	@Override
	@Transactional(readOnly=true)
	public Corporatecustomer validateCorporatecustomer(String email, String password) throws Exception {
		System.out.println("in validate Corporate Customer service");
		return dao.validateCorporateCustomer(email, password);
	}

	



	@Override
	public int saveFeedback(CorporatecustomerFeedback corporatecustomer) {
		System.out.println("saving feedback");
		return dao.feedbackCorporateCustomer(corporatecustomer);
	}
	

}
