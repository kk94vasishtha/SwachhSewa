package com.app.service;

import java.sql.SQLException;
import java.util.List;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Customercart;
import com.app.pojos.Product;
import com.app.pojos.Request;

public interface CustomerService {

	public int savedetails(Customer c) throws SQLException;
	public Customer validate(String email,String password) throws Exception;
	public List<CleanerInfo> getdetailsCleaner() throws Exception;
	public CleanerInfo getCleanerdetails(int id) throws NullPointerException;
	public Customer getCustomerid(String email, String password) throws Exception;
	public int request(Request r) throws NullPointerException;
	public List<Product> getProduct() throws Exception;
	public Product getProductDetails(int id) throws Exception;
	public int addcustomercart(Customercart c) throws Exception;
	
	public List<Customercart> getcartdetails(Customer c) throws Exception;
	
	Request getRequest(Integer customerId) throws Exception;
	public Customer getCustomer(Integer customerId) throws Exception;
	public String saveOrUpdate(Customer customer) throws Exception; //for edit details page to update the cleaner Info 
	String addMoneyToCustomer(Double updatedBalance,Integer customerId) throws Exception; // to update the balance or add money for addmoney page
    
	String deletecart(int id);
	public long genratebill(Customer c);
	public Request getOTP(String OTP);
}
