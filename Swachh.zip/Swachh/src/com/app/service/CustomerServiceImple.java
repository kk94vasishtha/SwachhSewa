package com.app.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.DaoCustomer;
import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Customercart;
import com.app.pojos.Product;
import com.app.pojos.Request;

@Service
@Transactional
public class CustomerServiceImple implements CustomerService {

	@Autowired
	private DaoCustomer dao;
	
	@Override
	public int savedetails(Customer c) throws SQLException {
		return dao.savedetails(c);
	}

	@Override
	public Customer validate(String email, String password) throws Exception {
		return dao.validate(email, password);
	}

	@Override
	public List<CleanerInfo> getdetailsCleaner() throws Exception {
		return dao.getdetailsCleaner();
	}

	@Override
	public CleanerInfo getCleanerdetails(int id) {
		// TODO Auto-generated method stub
		return  dao.getCleanerDetails(id);
	}

	@Override
	public Customer getCustomerid(String email, String password) throws Exception {
		return dao.getCustomerid(email, password);
	}

	@Override
	public int request(Request r) throws NullPointerException{
		return dao.request(r);
	}

	@Override
	public List<Product> getProduct() throws Exception {
		// TODO Auto-generated method stub
		return dao.getProductdetails();
	}

	@Override
	public Product getProductDetails(int id) throws Exception {
		return dao.getProductDetails(id);
	}

	@Override
	public int addcustomercart(Customercart c) throws Exception {
		return dao.addcustomercart(c);
	}

	@Override
	public List<Customercart> getcartdetails(Customer c) throws Exception {
		return dao.getcartdetails(c);
	}

	@Override
	public Request getRequest(Integer customerId) throws Exception {
		// TODO Auto-generated method stub
		return dao.getRequest(customerId);
	}

	@Override
	public String saveOrUpdate(Customer customer) throws Exception {
		// TODO Auto-generated method stub
		return dao.saveOrUpdate(customer);
	}

	@Override
	public String addMoneyToCustomer(Double updatedBalance, Integer customerId) throws Exception {
		// TODO Auto-generated method stub
		return dao.addMoneyToCustomer(updatedBalance, customerId);
	}

	@Override
	public Customer getCustomer(Integer customerId) throws Exception {
		return dao.getCustomer(customerId);
	}

	@Override
	public String deletecart(int id) {
		Customercart v = dao.getcartdetails(id);
		if(v!=null)
		return dao.deletecart(v);
	return "Delete cart Failed";	
	}

	@Override
	public long genratebill(Customer c) {
		return dao.genratebill(c);
	}

	@Override
	public Request getOTP(String OTP) {
		return dao.getOTP(OTP);
	}

}
