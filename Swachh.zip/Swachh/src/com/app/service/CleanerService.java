package com.app.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CleanerDAOInterface;
import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Request;

@Service
@Transactional
public class CleanerService implements CleanerServiceInterface {

	@Autowired
	private CleanerDAOInterface dao;
	
	public CleanerService() {
		System.out.println("In Cleaner Service constructor");
	}
	@Override
	public int saveCleaner(CleanerInfo cleanerInfo) {
		// TODO Auto-generated method stub
		System.out.println("saving the details of cleaner");
		return dao.registerCleaner(cleanerInfo);
	}
	@Override
	@Transactional(readOnly=true)
	public CleanerInfo validateCleaner(String mobile, String password)throws Exception {
		System.out.println("in validate cleaner service");
		return dao.validateCleaner(mobile, password);
	}
	
	//service for cleaner to print the list of customer who has confirmed him
	@Override
	public Customer checkRequest(Integer customerID) throws Exception {
		System.out.println("In check request service"); //for testing purpose only
		return dao.checkRequestMethod(customerID);
		
	}
	@Override
	public String updateStatus(Integer cleanerId) {
		System.out.println("In update status service");
		dao.updateStatus(cleanerId);
		return "success";
	}
	@Override
	public CleanerInfo getCleaner(int cleanerid) {
		System.out.println("getting the cleaner info in service");
		return dao.getCleaner(cleanerid);
	}
	@Override
	public String saveOrUpdate(CleanerInfo cleanerInfo) {
		System.out.println("updating the info in service");
		return dao.saveOrUpdate(cleanerInfo);
	}
	@Override
	public String addMoneyToCleaner(Double updatedBalance,Integer cleanerId) {
		System.out.println("in service class of updating the balance");
		return dao.addMoneyToCleaner(updatedBalance,cleanerId);
	}
	@Override
	public Request getRequest(int cleanerid) {
		System.out.println("In request service class" + cleanerid);
		return dao.getRequest(cleanerid);
	}
	
}
