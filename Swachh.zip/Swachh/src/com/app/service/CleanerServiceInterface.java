package com.app.service;

import java.util.List;

import com.app.pojos.CleanerInfo;
import com.app.pojos.Customer;
import com.app.pojos.Request;

public interface CleanerServiceInterface {
	public int saveCleaner(CleanerInfo cleanerInfo);
	public CleanerInfo validateCleaner(String mobile,String password)throws Exception;
	public Customer checkRequest(Integer customerID) throws Exception;
	public String updateStatus(Integer cleanerId);
	public CleanerInfo getCleaner(int cleanerid);
	public Request getRequest(int cleanerid);
	public String saveOrUpdate(CleanerInfo cleanerInfo);
	String addMoneyToCleaner(Double updatedBalance,Integer cleanerId);
}
